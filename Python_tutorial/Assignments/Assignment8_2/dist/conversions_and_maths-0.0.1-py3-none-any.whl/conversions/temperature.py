def fahr_to_celsius(temperature):
    
    return (temperature - 32) * (5 / 9)

